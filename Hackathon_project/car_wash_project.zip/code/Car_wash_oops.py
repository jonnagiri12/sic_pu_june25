import Car_wash_crud as crud

class Car_wash():
    def __init__(self):
        print("Enter to Car wash App")
    
    def menu(self, choice):
        match choice:
            case 1 : crud.discount_month()
            case 2 : crud.surcharge_month()
            case 3 : crud.coupon_customers()
            case 4 : crud.monthly_sales_of_year()
            case 5 : crud.display_ofsales_using_piechart()
            case 6 : crud.customers_ranking()
            case 7 : pass
            case _ : print("Invaild choice")
    
    def start_app(self):
        while True:
            print("Car wash menu :")
            print("1. Discount Month\n2. Surcharge Month\n3. Coupon Customers\n4. Monthly sales of a year\n" \
            "5. Display sales using piechart\n6. Customer Ranking\n7. Exit")
            choice = int(input("Enter choice : "))
            if choice == 7:
                return
            self.menu(choice)
            

car_wash = Car_wash()
car_wash.start_app()