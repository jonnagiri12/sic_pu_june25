import pymysql
import pandas as pd
import matplotlib.pyplot as plt

def connect_db():
    connection = None
    try:
        connection = pymysql.connect(host='localhost', user="root", password="Bobby@1211", database='sheshadri_db', port=3306, charset="utf8")
    except:
        print('Database Connection Failed')
    return connection

def disconnect_db(connection):
    try:
        connection.close()
    except:
        print('Database disconnection failed')

def create_table():
    query = 'CREATE TABLE IF NOT EXISTS car_wash_sales (date DATETIME, cust_id INT, service_id INT, amount INT, hour INT, day_part VARCHAR(50), month INT);'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        print('Car wash sales Table created')
        cursor.close()
        disconnect_db(connection)
    except:
        print("Table creation failed")

create_table()

def insert_data():
    connection = connect_db()
    cursor = connection.cursor()

    # Check if data already exists (e.g., check if the table is empty)
    cursor.execute("SELECT COUNT(*) FROM car_wash_sales")
    if cursor.fetchone()[0] > 0:
        print("Data already exists in 'sales' table. Skipping insertion.")
        cursor.close()
        connection.close()
        return

    with open('\Resources\car_wash_sales.sql', 'r') as file:
        sql_script = file.read()

    for statement in sql_script.split(';'):
        stmt = statement.strip()
        if stmt:
            try:
                cursor.execute(stmt)
            except Exception as e:
                print(f"Failed to execute: {stmt[:80]}...\nError: {e}")

    connection.commit()
    cursor.close()
    connection.close()

insert_data()

def discount_month():
    query = 'SELECT MONTH(date) AS month, SUM(amount) AS revenue FROM car_wash_sales GROUP BY MONTH(date) ORDER BY revenue ASC LIMIT 1;'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("*" * 70)
        print("Discount month : ")
        for row in rows:
            print(f"Month :", row[0])
            print(f"Amount :", row[1])
        print("*" * 70)
        cursor.close()
        disconnect_db(connection)
    except:
        print('Error in finding discount month')


def surcharge_month():
    query = 'SELECT MONTH(date) AS month, SUM(amount) AS revenue FROM car_wash_sales GROUP BY MONTH(date) ORDER BY revenue DESC LIMIT 1;'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("*" * 70)
        print("Surcharge month : ")
        for row in rows:
            print(f"Month :", row[0])
            print(f"Amount :", row[1])
        print("*" * 70)
        cursor.close()
        disconnect_db(connection)
    except:
        print('Error in finding surcharge month')


def coupon_customers():
    query = 'SELECT cust_id, MAX(date) AS last_visit, SUM(amount) AS total_spent FROM car_wash_sales GROUP BY cust_id ORDER BY total_spent DESC LIMIT 5;'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("*" * 70)
        print("Coupon to the valuable customers : ")
        for row in rows:
            print(f"Customer Id : ", row[0])
            print(f"Last visit  : ", row[1])
            print(f"Total spent : ", row[2])
            print()
        print("*" * 70)
        cursor.close()
        disconnect_db(connection)
    except:
        print('Error in finding coupons of customer')


def customers_ranking():
    query = 'SELECT cust_id, SUM(amount) AS total_spent FROM car_wash_sales GROUP BY cust_id ORDER BY total_spent DESC LIMIT 5;'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("*" * 70)
        print("Top Customer ranking : ")
        for row in rows:
            print("Cutomer ID  :", row[0])
            print("Total spent :", row[1])
            print()
        print("*" * 70)
        cursor.close()
        disconnect_db(connection)
    except:
        print('Error in finding customer ranking')


def monthly_sales_of_year():
    query = 'SELECT MONTH(date) AS month, SUM(amount) AS revenue FROM car_wash_sales WHERE YEAR(date) = 2025 GROUP BY MONTH(date);'
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("*" * 70)
        print("Monthly sales of year : ")
        for row in rows:
            print(f"Month   : ", row[0])
            print(f"Revenue : ", row[1])
            print()
        print("*" * 70)
        cursor.close()
        disconnect_db(connection)
    except:
        print('Error in finding of monthly sales of year')


def display_ofsales_using_piechart():
    # csv_path = "car_wash_sales_data.csv"
    df = pd.read_csv("C:\learning\sic_pu_june25\Hackathon_project_carwash\Resources\car_wash_sales_data.csv")

    # Assume df is the DataFrame of sales
    df['hour'] = pd.to_datetime(df['date']).dt.hour
    df['day_part'] = pd.cut(df['hour'],
                            bins=[0, 6, 12, 18, 24],
                            labels=['Night', 'Morning', 'Afternoon', 'Evening'],
                            right=False)

    day_part_sales = df.groupby('day_part')['amount'].sum()

    day_part_sales.plot.pie(autopct='%1.1f%%', title='Sales by Time of Day')
    plt.ylabel('')
    plt.show()